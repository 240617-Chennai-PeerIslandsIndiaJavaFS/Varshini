package org.example.model;

public enum Role {
    ADMIN,
    PROJECT_MANAGER,
    TEAM_MEMBER;
}
