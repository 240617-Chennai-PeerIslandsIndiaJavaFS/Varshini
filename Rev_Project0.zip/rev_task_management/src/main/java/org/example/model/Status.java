package org.example.model;

public enum Status {
    ACTIVE,
    INACTIVE,
    PENDING
}
