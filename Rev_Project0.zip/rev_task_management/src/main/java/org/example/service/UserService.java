package org.example.service;

import org.example.model.Role;
import org.example.model.Users;

import java.util.Scanner;
import java.util.regex.Pattern;

public class UserService {


}
